import casafeliz

pisos = 10
departamentos_por_piso = 4
departamentos = [['Disponible'] * departamentos_por_piso for _ in range(pisos)]

precios = [
    [3800, 3000, 2800, 3500],
    [3800, 3000, 2800, 3500],
    [3800, 3000, 2800, 3500],
    [3800, 3000, 2800, 3500],
    [3800, 3000, 2800, 3500],
    [3800, 3000, 2800, 3500],
    [3800, 3000, 2800, 3500],
    [3800, 3000, 2800, 3500],
    [3800, 3000, 2800, 3500],
    [3800, 3000, 2800, 3500]
]

compradores = [[''] * departamentos_por_piso for _ in range(pisos)]

def mostrar_menu():
    print("Casa Feliz")
    print("1. Comprar departamento")
    print("2. Mostrar departamentos disponibles")
    print("3. Ver listado de compradores")
    print("4. Mostrar ganancias totales")
    print("5. Salir")

def main():
    while True:
        mostrar_menu()
        opcion = input("Ingrese una opcion (1-5): ")
        
        if not opcion:
            print("No se ha ingresado ninguna opcion, intente nuevamente.")
            continue
        
        if opcion == '1':
            casafeliz.comprar_departamento(departamentos, pisos, departamentos_por_piso, precios, compradores)
        elif opcion == '2':
            casafeliz.mostrar_departamentos_disponibles(departamentos, pisos, departamentos_por_piso)
        elif opcion == '3':
            casafeliz.ver_listado_compradores(compradores, pisos, departamentos_por_piso)
        elif opcion == '4':
            casafeliz.mostrar_ganancias_totales(departamentos, pisos, departamentos_por_piso, precios)
        elif opcion == '5':
            casafeliz.salir()
            break
        else:
            print("Opcion invalida, intente nuevamente.")

main()
