import datetime

def comprar_departamento(departamentos, pisos, departamentos_por_piso, precios, compradores):
    print("Departamentos disponibles:")
    disponibilidad = [['[ ]'] * departamentos_por_piso for _ in range(pisos)]
    for piso in range(pisos):
        for departamento in range(departamentos_por_piso):
            estado = departamentos[piso][departamento]
            if estado != 'Disponible':
                disponibilidad[piso][departamento] = '[X]'
    
    for piso in range(pisos):
        piso_nombre = f"Piso {piso+1}"
        tipos_habitaciones = disponibilidad[piso]
        print(f"{piso_nombre:<12}{' '.join(tipos_habitaciones)}")
    
    piso_input = input("Ingrese el numero de piso: ")
    tipo_input = input("Ingrese el tipo de departamento (A, B, C o D): ")
    
    if not piso_input or not tipo_input:
        print("No se ha ingresado el numero de piso o el tipo de departamento. Intente nuevamente.")
        return
    
    piso = int(piso_input)
    tipo = tipo_input.upper()
    
    if piso < 1 or piso > pisos:
        print("Piso invalido. Intente nuevamente.")
        return
    
    if tipo < 'A' or tipo > 'D':
        print("Tipo de departamento invalido. Intente nuevamente.")
        return
    
    departamento_index = ord(tipo) - ord('A')
    
    if departamentos[piso-1][departamento_index] == 'Disponible':
        run = input("Ingrese el RUN del comprador (sin guiones ni puntos): ")
        
        if run.isdigit() and len(run) >= 7:
            departamentos[piso-1][departamento_index] = 'Vendido'
            compradores[piso-1][departamento_index] = run
            print("Operacion realizada correctamente")
        else:
            print("RUN invalido. Intente nuevamente.")
    else:
        print("El departamento seleccionado no esta disponible.")

def mostrar_departamentos_disponibles(departamentos, pisos, departamentos_por_piso):
    print("Estado actual de los departamentos:")
    disponibilidad = [['[ ]'] * departamentos_por_piso for _ in range(pisos)]
    for piso in range(pisos):
        for departamento in range(departamentos_por_piso):
            estado = departamentos[piso][departamento]
            if estado != 'Disponible':
                disponibilidad[piso][departamento] = '[X]'
    
    for piso in range(pisos):
        piso_nombre = f"Piso {piso+1}"
        tipos_habitaciones = disponibilidad[piso]
        print(f"{piso_nombre:<12}{' '.join(tipos_habitaciones)}")

def ver_listado_compradores(compradores, pisos, departamentos_por_piso):
    print("Listado de compradores por RUN (ordenado de menor a mayor):")
    compradores_list = []
    for piso in range(pisos):
        for departamento in range(departamentos_por_piso):
            run = compradores[piso][departamento]
            if run:
                compradores_list.append((run, f"{chr(ord('A')+departamento)}{piso+1}"))
    compradores_list.sort()
    for run, departamento in compradores_list:
        print(f"{run}: {departamento}")

def mostrar_ganancias_totales(departamentos, pisos, departamentos_por_piso, precios):
    ventas_totales = 0
    print("Ventas totales:")
    print("Tipo de Departamento\tCantidad\tTotal")
    for departamento in range(departamentos_por_piso):
        cantidad = sum([1 for piso in range(pisos) if departamentos[piso][departamento] == 'Vendido'])
        total = cantidad * precios[0][departamento]
        ventas_totales += total
        print(f"Tipo {chr(ord('A')+departamento)}\t\t{cantidad}\t\t{total} UF")
    print(f"TOTAL\t\t\t\t\t\t\t{ventas_totales} UF")

def salir():
    print("Gracias por utilizar Casa Feliz")
    now = datetime.datetime.now()
    print(f"Fecha y hora: {now.strftime('%Y-%m-%d %H:%M:%S')}")
